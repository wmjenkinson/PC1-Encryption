/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * pukall_pc1.h
 *
 * Created: 18/04/2017 21:22:30
 *  Author: wmjen
 */ 


#ifndef PUKALL-PC1_H_
#define PUKALL-PC1_H_


 #include<stdio.h>
 #include<string.h>

void pc1(void);

 /*Global variable*/
 unsigned short ax,bx,cx,dx,si,tmp,x1a2,x1a0[16],res,i,inter,cfc,cfd,compte;
 unsigned char key[] = "abcdefghijklmnopqrstuvwxyz112345";

 unsigned char test[] = "The quick brown fox jumps over the lazy dog. ";


 char c;
 int k = 0, j = 0, l = 0;
 int c1,count;
 short d,e;
 /*End global variable*/

 /*Function def*/
 int fin();

 int assemble();
 int code();

 // PC1 is a stream cipher with a retro-action function.
void pc1(void){

	 fin();
	 printf("Imaged Sequence    ");
	 printf("\n");

	 c = test[k++];
	 while(c != '\0'){

		 printf("%c", c);
		 assemble();

		 cfc = (char) ( inter >> 8);
		 cfd = (char) ( inter & 255); /* cfc^cfd = random byte */

		 /* K ZONE !!!!!!!!!!!!! */
		 /* here the mix of c and key[compte] is after the decryption of c */
		 c = c ^ (cfc^cfd);
		 for (compte = 0; compte <= 31; compte++){

			 /* we mix the plaintext byte with the key */
			 key[compte] = (key[compte] ^ c);
		 }

		 test[k - 1] = c;
		 c = test[k++];
	 }

	 fin();
	 k = 0;
	 c = test[k++];

	 printf("\n");
	 printf("\n");
	 printf("Encrypted Sequence ");
	 printf("\n");

	 // encrypted sequence
	 while( c != '\0'){
		 printf("%c", c);
		 c = test[k++];
	 }

	 printf("\n");
	 printf("\n");
	 printf("Re-imaged Sequence");
	 printf("\n");

	 k = 0;
	 c = test[k++];

	 while( c != '\0'){

		 assemble();

		 cfc = (inter >> 8);
		 cfd = (inter & 255); /* cfc^cfd = random byte */

		 /* K ZONE !!!!!!!!!!!!! */
		 /* here the mix of c and key[compte] is before the encryption of c */
		 for (compte = 0; compte <= 31; compte++){

			 /* we mix the plaintext byte with the key */
			 key[compte] = (key[compte] ^ c);
		 }
		 c = c ^ (cfc ^ cfd);
		 printf("%c", c);

		 c = test[k++];
	 }
	 fin();
 }


 int code(){

	 dx = x1a2+i;
	 ax = x1a0[i];
	 cx = 0x015a;
	 bx = 0x4e35;

	 tmp = ax;
	 ax = si;
	 si = tmp;

	 tmp = ax;
	 ax = dx;
	 dx = tmp;

	 if (ax != 0){
		 ax =ax * bx;
	 }

	 tmp = ax;
	 ax = cx;
	 cx = tmp;

	 if (ax != 0){
		 ax =ax * si;
		 cx =ax + cx;
	 }

	 tmp = ax;
	 ax = si;
	 si = tmp;
	 ax =ax * bx;
	 dx =cx + dx;

	 ax =ax + 1;

	 x1a2 = dx;
	 x1a0[i] = ax;

	 res =ax ^ dx;
	 i = i + 1;
	 return 0;
 }

 int assemble(){

	 x1a0[0]= ( key[0]*256 )+ key[1];
	 code();
	 inter=res;

	 x1a0[1]= x1a0[0] ^ ( (key[2]*256) + key[3] );
	 code();
	 inter=inter^res;

	 x1a0[2]= x1a0[1] ^ ( (key[4]*256) + key[5] );
	 code();
	 inter=inter^res;

	 x1a0[3]= x1a0[2] ^ ( (key[6]*256) + key[7] );
	 code();
	 inter=inter^res;

	 x1a0[4]= x1a0[3] ^ ( (key[8]*256) + key[9] );
	 code();
	 inter=inter^res;

	 x1a0[5]= x1a0[4] ^ ( (key[10]*256) + key[11] );
	 code();
	 inter=inter^res;

	 x1a0[6]= x1a0[5] ^ ( (key[12]*256) + key[13] );
	 code();
	 inter=inter^res;

	 x1a0[7]= x1a0[6] ^ ( (key[14]*256) + key[15] );
	 code();
	 inter=inter^res;

	 x1a0[8]= x1a0[7] ^ ( (key[16]*256) + key[17] );
	 code();
	 inter=inter^res;

	 x1a0[9]= x1a0[8] ^ ( (key[18]*256) + key[19] );
	 code();
	 inter=inter^res;

	 x1a0[10]= x1a0[9] ^ ( (key[20]*256) + key[21] );
	 code();
	 inter=inter^res;

	 x1a0[11]= x1a0[10] ^ ( (key[22]*256) + key[23] );
	 code();
	 inter=inter^res;

	 x1a0[12]= x1a0[11] ^ ( (key[24]*256) + key[25] );
	 code();
	 inter=inter^res;

	 x1a0[13]= x1a0[12] ^ ( (key[26]*256) + key[27] );
	 code();
	 inter=inter^res;

	 x1a0[14]= x1a0[13] ^ ( (key[28]*256) + key[29] );
	 code();
	 inter=inter^res;

	 x1a0[15]= x1a0[14] ^ ( (key[30]*256) + key[31] );
	 code();
	 inter=inter^res;

	 i=0;
	 return 0;
 }

 int fin(){

	 /* erase all variables */
	 for (compte=0;compte<=31;compte++){
		 key[compte]=0;
	 }
	 ax = 0;
	 bx = 0;
	 cx = 0;
	 dx = 0;
	 si = 0;
	 tmp = 0;
	 x1a2 = 0;
	 x1a0[0] = 0;
	 x1a0[1] = 0;
	 x1a0[2] = 0;
	 x1a0[3] = 0;
	 x1a0[4] = 0;
	 res = 0;
	 i = 0;
	 inter = 0;
	 cfc = 0;
	 cfd = 0;
	 compte = 0;
	 c = 0;
	 return 0;
 }



#endif /* PUKALL-PC1_H_ */